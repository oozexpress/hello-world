#!/bin/env bash

echo `python main.py --port=8080 --daemonize True`

